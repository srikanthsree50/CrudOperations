const Student = require('../models/student');
const ClassStud = require('../models/classStud');

const getStudentByRollNo = async (req,res) => {
    try{
const student = await Student.findOne({rollNo:req.body.rollNo});
if(student){
    return res.status(200).json({
       data: student,
       message:'student fetched successfully....',
       success:true
    });
}
return res.status(404).json({
    message: 'student not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}   

    const getStudents = async(req,res) => {
        try {
const [students] = await Promise.all([Student.find({}).exec()]);
if(students){
    return res.status(200).json({
        data:students,
    message:' fetching students successfull....',
    success:true
    });
}
return res.status(404).json({
    message: 'students not found ',
    success:false
});
        }
        catch(err){
            return res.status(500).json({
                message:err.message,
                success:false
            })
        }
    }
    
const insertStudent = async (req,res) => {
    try{

        let  totalMarks = {};
        totalMarks = req.body.marks;
      let sum = 0;
   let keys = Object.keys(totalMarks);
    keys.forEach((key,index) => {
sum += totalMarks[key]
return sum; 
})

const student = new Student({
    _id:req.body.id,
    rollNo:req.body.rollNo,
    name:req.body.name,
    fatherName:req.body.fatherName,
    marks:req.body.marks,
    totalMarks:sum,
    classId:req.body.classId
});

const classStud = new ClassStud({
    studentId:req.body.id,
    classId:req.body.classId
})
        await student.save();
     await classStud.save();
    return res.status(201).json({
        message:'student inserted successfully',
        success:true
    });
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
}

const updateStudent = async(req,res) => {
    try {
        
        let  totalMarks = {};
        totalMarks = req.body.marks;
      let sum = 0;
   let keys = Object.keys(totalMarks);
    keys.forEach((key,index) => {
sum += totalMarks[key]
return sum; 
 })
req.body.totalMarks = sum;

    await Student.findByIdAndUpdate(req.params.id,req.body);
    return res.status(201).json({
        message:'student updated successfully',
        success:true
    });
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
    }

const deleteStudent = async(req,res) => {
    try{
   const student = await Student.findByIdAndDelete(req.params.id);
   if(!student){
       return res.status(404).json({
           message:'student not found...',
           success:false
       })
   }
   return res.status(201).json({
       message:'student deleted successfully...',
       success:true
   })
    }   
    catch(err){
       return res.status(500).json({
           message:err.message,
           success:false
       })
    }
   }

module.exports = {
    getStudentByRollNo,
    getStudents,
    insertStudent,
    updateStudent,
    deleteStudent
}