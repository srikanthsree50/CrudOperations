const Class = require('../models/class');
const ClassStud = require('../models/classStud');


const getClassByNo = async(req,res) => {
    try{
const classdata = await Class.findOne({classNo:req.body.classNo});
if(classdata){
    return res.status(200).json({
        classdata,
        message:' classdetails fetched successfully....',
        message:true
    });
}
return res.status(404).json({
    message: 'classDetails not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}   
    
    const getClasses = async(req,res) => {
        try {

const [classes] = await Promise.all([Class.find({}).exec()]);
if(classes){
    return res.status(201).json({
        data: classes,
        message: ' fetched classes successfully....',
        success:true
    });
}
return res.status(404).json({
    message: 'classes not found ',
    success:false
});
        }
        catch(err){
            return res.status(500).json({
                message:err.message,
                success:false
            })
        }
    }

const insertClass = async (req,res) => {
    try{
        const classInsert = new Class({
                _id:req.body.id,
                classNo:req.body.classNo,
                className:req.body.className,
                teacherName:req.body.teacherName,
                studentId:req.body.studentId
        });
        const classStud = new ClassStud({
            studentId:req.body.studentId,
            classId:req.body.id
        })
        await classInsert.save();
        await classStud.save();
        
    return res.status(201).json({
        message:'class inserted successfully',
        success:true
    });
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
}


const updateClass = async(req,res) => {
    try {
      
    await Class.findByIdAndUpdate(req.params.id,req.body);
    return res.status(201).json({
        message:'class updated successfully',
        success:true
    });
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
    }


    const deleteClass = async(req,res) => {
        try{
       const classObj = await Class.findByIdAndDelete(req.params.id);
       if(!classObj)
       {
       return res.status(404).json({
        message:'class not found...',
        success:false
        })
       }
       
    return res.status(200).json({
        message:'class deleted successfully...',
        success:true
    })
       }
        catch(err){
           return res.status(500).json({
               message:err.message,
               success:false
           })
        }
       }

module.exports = {
    getClassByNo,
    getClasses,
    insertClass,
    updateClass,
    deleteClass
}