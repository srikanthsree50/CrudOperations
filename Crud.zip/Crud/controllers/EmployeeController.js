const Employee = require('../models/employee');

const getEmployeeById = async(req,res) => {
    try{
    
const employee = await Employee.findById(req.params.id);
if(employee){
    return res.status(200).json({
        employee,
        message: 'employee fetched successfully..',
        success:true
    });
}
return res.status(404).json({
    message: 'employee not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}
    
    const getEmployees = async(req,res) => {
        try {

const [employees] = await Promise.all([Employee.find({}).exec()]);

if(employees){
    return res.status(201).json({
        object:"list",
        data: employees,
        message:' employees fetched successfully...',
        success:true
    });
}
return res.status(404).json({
    message: 'employees not found ',
    success:false
});
        }
        catch(err){
            return res.status(500).json({
                message:err.message,
                success:false
            })
        }
    }


const createEmployee = async (req,res) => {
return new Promise(async(resolve,reject) => {

    try{
        const employee = new Employee({
            _id:req.body.id,
            name:req.body.name,
            salary:req.body.salary,
            location:req.body.location
        });

    const emp  = await employee.save();
    return res.status(201).json({
        message:'employee created successfully',
        success:true
    });
    }
    catch(err){
        reject(err);
       return res.status(500).json({
            message:err.message,
            success:false
        })
    }
})
}


const updateEmployee = async(req,res) => {
try {
    
await Employee.findByIdAndUpdate(req.params.id,req.body);
 
return res.status(201).json({
    message:'employee updated successfully',
    success:true
});
}
catch(err){
    return res.status(500).json({
        message:err.message,
        success:false
    })
}
}

const deleteEmployee = async(req,res) => {
 try{
const employee = await Employee.findByIdAndDelete(req.params.id);
if(!employee){
    return res.status(404).json({
        message:'employee not found...',
        success:false
    })
}
return res.status(200).json({
    message:'employee deleted successfully...',
    success:true
})
 }   
 catch(err){

    return res.status(500).json({
        message:err.message,
        success:false
    })
 }
}

module.exports = {
    getEmployeeById,
    getEmployees,
    createEmployee,
    updateEmployee,
    deleteEmployee

}