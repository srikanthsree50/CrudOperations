const Class = require('../models/class');
const Student = require('../models/student');
const ClassStud = require('../models/classStud')

const getStudentsDetailsByClassId = async(req,res) => {
    try{
const studentDetails = await Class.findById(req.params.id);
if(studentDetails){
    return res.status(200).json(studentDetails);
}
return res.status(404).json({
    message: 'studentDetails not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}
        
const getClassDetailsByStudentId = async(req,res) => {
    try{
const classDetails = await Student.findById(req.params.id);
if(classDetails){
    return res.status(200).json(classDetails);
}
return res.status(404).json({
    message: 'classDetails not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}

const insertClassIdClassStud = async (req,res) => {
    try{
        const insertClassId = new ClassStud({
                classId:req.body.id,
                studentId:req.body.studentId
        });
        await insertClassId.save();

    return res.status(201).json({
        message:'classIdStud inserted successfully',
        success:true
    });
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
}

const insertStudentIdClassStud = async(req,res) => {
    try{
        const insertStudentId = new ClassStud({
                studentId:req.body.id,
                classId:req.body.classId
        });
        await insertStudentId.save();

    return res.status(201).json({
        message:'StudentIdStud inserted successfully',
        success:true
    });
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }   
}

const deleteClassDetailsByStudentId = async(req,res) => {

    try{
       // const classObj = await Class.findByIdAndDelete({studentId:req.params.studentId}); // delete by reqParameters
        const classObj = await Class.findByIdAndDelete({studentId:req.body.studentId}); // delete by reqBody
        if(!classObj)
        {
        return res.status(404).json({
         message:'class not found...',
         success:false
         })
        }
        
     return res.status(200).json({
         message:'class deleted successfully...',
         success:true
     })
        }
         catch(err){
            return res.status(500).json({
                message:err.message,
                success:false
            })
         }
}


const deleteStudentsDetailsByClassId = async(req,res) => {

    try{
      //  const student = await Student.findByIdAndDelete({classId:req.params.classId}); // delete by using reqParams
      const student = await Student.findByIdAndDelete({classId:req.body.classId});  // delete by using reqBody
        if(!student){
            return res.status(404).json({
                message:'student not found...',
                success:false
            })
        }
        return res.status(201).json({
            message:'student deleted successfully...',
            success:true
        })
         }   
         catch(err){
            return res.status(500).json({
                message:err.message,
                success:false
            })
         }
}

module.exports = {
    getClassDetailsByStudentId,
    getStudentsDetailsByClassId,
    insertClassIdClassStud,
    insertStudentIdClassStud,
    deleteClassDetailsByStudentId,
    deleteStudentsDetailsByClassId
}