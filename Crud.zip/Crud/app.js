const path = require('path');
const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const cors = require('cors');
const { connect } = require('mongoose');

const Url = 'mongodb://localhost:27017/NodeDB';
const port = process.env.PORT || 3000;

const app = express();
const employeeRoute = require('./routes/employee')
const classRoute = require('./routes/class');
const studentRoute = require('./routes/student');
const classStudRoute = require('./routes/classStud');

app.use(cors());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}));

app.use('/',express.static(path.join('/public')));
app.use('/api/employee',employeeRoute)
app.use('/api/class',classRoute)
app.use('/api/student',studentRoute)
app.use('/api/classstud',classStudRoute)

const startApp = async () => {
  try{
await connect(Url, {
useFindAndModify: false,
useUnifiedTopology: true,
useNewUrlParser: true,
useCreateIndex: true
});
console.log('successfully connected to database...');

app.listen(port,() => {
  console.log(`Server started Successfully on Port : ${port}`);
})

  }
  catch(err){
console.log(err);
startApp();
  }
}

startApp();