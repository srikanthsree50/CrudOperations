const  ObjectId  = require('mongodb').ObjectId;
const { Schema, model } = require('mongoose');

const studentSchema = new Schema({
    id: ObjectId,
    rollNo: {
         type : Number,
         required : true 
        },
    name: {
         type : String,
         required : true
         },
    fatherName: { 
        type : String,
        required : true 
    },
    marks: {
         telugu : {
             type: Number,
             required: true
            },
         hindi : {
             type: Number,
             required: true
            },
         english :{ 
             type: Number,
             required: true
            },
         maths : {
            type: Number,
            required: true 
        },
         science : { 
             type: Number, 
             required: true
            },
         social : {
             type: Number,
             required: true
            },
 },
 totalMarks: {
    type: Number,
     required : true
 },
classId: { 
              type: Schema.Types.ObjectId,
              ref:'Class'
    }
}, {timestamps:true})

// totalMarks.aggregate([
//     {$project :{$add:["$telugu","$hindi","$english","$maths","$science","$social"]}}
// ])

module.exports = model("Student",studentSchema);