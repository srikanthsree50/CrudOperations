const  ObjectId  = require('mongodb').ObjectId;
const { Schema, model } = require('mongoose');

const classSchema = new Schema({
    id: ObjectId,
    classNo:  {
         type : Number,
         required : true
         },
    className: {
         type : String,
          required : true 
        },
    teacherName: { 
        type : String, 
        required : true
     },
    studentId: {
         type : Schema.Types.ObjectId,
         ref:'Student'
        }
},{timestamps:true})

module.exports = model("Class",classSchema);