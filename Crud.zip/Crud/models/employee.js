const  ObjectId  = require('mongodb').ObjectId;
const {Schema,model} = require('mongoose');

    const employeeSchema = new Schema({
    id: ObjectId,
    name: {
        type: String,
        required: true
    },
    salary: {
        type: Number,
        required: true
    },
    location: { 
        type: String, 
        required: true 
    }
},{timestamps:true});

module.exports = model("Employee",employeeSchema);