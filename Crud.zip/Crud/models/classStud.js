
const {Schema, model} = require('mongoose');

const classStudSchema = new Schema({
    classId: { 
         type : Schema.Types.ObjectId,
         ref:'Class'
    },
    studentId: {
        type : Schema.Types.ObjectId ,
        ref:'Student'
     }
},{timestamps:true})

module.exports = model("ClassStud",classStudSchema);
