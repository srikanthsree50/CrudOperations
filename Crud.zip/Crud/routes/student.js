const express = require('express');
const router = express.Router();
const { getStudentByRollNo, getStudents , insertStudent , updateStudent , deleteStudent } = require('../controllers/studentController');
const { insertStudentIdClassStud } = require( '../controllers/classStudController');

router.get('/', async(req,res) => {
await getStudents(req,res);
});

router.post('/', async (req,res) =>{
await insertStudent(req,res);
});

router.get('/:id', async (req,res) => {
    await getStudentByRollNo(req,res);
});

router.put('/:id', async (req,res) => {
    await updateStudent(req,res);
});

router.delete('/:id', async (req,res) => {
    await deleteStudent(req,res);
});

module.exports = router;