const router = require('express').Router();
const { getEmployeeById, getEmployees, createEmployee, updateEmployee, deleteEmployee } = require('../controllers/EmployeeController')

router.get('/:id', async (req,res) => {
    await getEmployeeById(req,res);
});

router.get('/', async (req,res) => {
  await  getEmployees(req,res);
});

router.post('/', async (req,res) => {
   await createEmployee(req,res);
})

router.put('/:id', async (req,res) => {
    await updateEmployee(req,res);
});

router.delete('/:id', async (req,res) => {
    await deleteEmployee(req,res);
});

module.exports = router; 