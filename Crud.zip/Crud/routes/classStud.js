const express = require('express');
const router = express.Router();

const { getStudentsDetailsByClassId , getClassDetailsByStudentId , insertClassIdClassStud ,insertStudentIdClassStud ,
    deleteClassDetailsByStudentId,
    deleteStudentsDetailsByClassId } = require('../controllers/classStudController');

router.get('/getstudclass/:id', async (req,res) => {
    await getStudentsDetailsByClassId(req,res);
});

router.get('/getstudclass/:id', async (req,res) => {
    await getClassDetailsByStudentId(req,res);
});

router.post('/', async (req,res) =>{
    await insertClassIdClassStud(req,res);
    });    

router.post('/', async (req,res) =>{
    await insertStudentIdClassStud(req,res);
    });
    
    router.post('/', async (req,res) =>{
        await deleteClassDetailsByStudentId(req,res);
        });    
    
    router.post('/', async (req,res) =>{
        await deleteStudentsDetailsByClassId(req,res);
        });

module.exports = router;