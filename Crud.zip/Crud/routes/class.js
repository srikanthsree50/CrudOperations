const express = require('express');
const router = express.Router();

const { insertClassIdClassStud } = require('../controllers/classStudController');
const { insertClass, getClasses , getClassByNo , updateClass , deleteClass} = require('../controllers/classController');

router.get('/', async(req,res) => {
await getClasses(req,res);
});

router.post('/', async (req,res) =>{
await insertClass(req,res);
});

router.get('/:id', async (req,res) => {
    await getClassByNo(req,res);
});

router.put('/:id', async (req,res) => {
    await updateClass(req,res);
});

router.delete('/:id', async (req,res) => {
    await deleteClass(req,res);
});

module.exports = router;